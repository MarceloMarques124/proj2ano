package com.example.restmanager.Model;

public class User {

    private int Id;
    private String Usermane;
    private String Address;
    private String DoorNumber;
    private String PostalCode;
    private int NIF;
    private String email;
    private String Password;


}
