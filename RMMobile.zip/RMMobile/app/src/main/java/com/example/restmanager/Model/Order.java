package com.example.restmanager.Model;

public class Order {
    private int id;

    public int getId() {
        return id;
    }
}
