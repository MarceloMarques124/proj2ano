package com.example.restmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ReserveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve);
        setTitle("teste");
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}