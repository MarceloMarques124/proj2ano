<?php // roles_data.php

return [
  'admin' => [
    'name' => 'admin',
    'type' => 1,
    'description' => 'Administrator',
    'rule_name' => null,
    'data' => null,
    'created_at' => time(),
    'updated_at' => time(),
  ],
];
