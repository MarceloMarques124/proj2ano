package com.example.restmanager.Listeners;

public interface ReviewListener {

    void onRefreshReviewDetails(int operation);
}
