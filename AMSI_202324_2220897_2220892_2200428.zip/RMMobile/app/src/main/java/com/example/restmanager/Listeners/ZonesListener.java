package com.example.restmanager.Listeners;

import com.example.restmanager.Model.Zone;

import java.util.ArrayList;

public interface ZonesListener {

    void onRefreshZonesListener(ArrayList<Zone> zones);
}
