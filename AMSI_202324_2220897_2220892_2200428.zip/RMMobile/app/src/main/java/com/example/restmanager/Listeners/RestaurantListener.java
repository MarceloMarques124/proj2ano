package com.example.restmanager.Listeners;

public interface RestaurantListener {

    void onRefreshRestaurantDetails(int operation);
}
