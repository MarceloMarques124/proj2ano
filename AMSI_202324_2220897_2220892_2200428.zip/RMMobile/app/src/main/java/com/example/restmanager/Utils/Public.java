package com.example.restmanager.Utils;

public class Public {

    public static final String TOKEN = "TOKEN";
    public static final String DATAUSER = "DataUser";
    public static final String IP = "http://172.22.21.221:8080/api";
}