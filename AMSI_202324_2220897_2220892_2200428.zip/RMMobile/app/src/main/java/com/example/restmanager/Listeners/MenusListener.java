package com.example.restmanager.Listeners;

import com.example.restmanager.Model.Menu;

import java.util.ArrayList;

public interface MenusListener {

    void onRefreshMenusList(ArrayList<Menu> menus);
}
